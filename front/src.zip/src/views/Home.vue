<template>
  <EventMe msg="Welcome to Your Vue.js App" />
</template>

<script>
import EventMe from "@/components/EventMe.vue";

export default {
  name: "Home",
  components: {
    EventMe,
  },
};
</script>

<style scoped>
</style>