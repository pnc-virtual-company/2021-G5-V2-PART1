<template>
  <div>
    <small class="text-white mt-5">
      <slot></slot>
      </small>
  </div>
</template>
<script>
export default {
  props: ["btn_name"],
  data() {
    return {};
  },
};
</script>
<style scoped>
</style>