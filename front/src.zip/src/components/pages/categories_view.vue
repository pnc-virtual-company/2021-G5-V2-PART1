<template>
  <div>
    <section v-if="alert_act === 'create'">
      <Base-alert v-if="alert_me" class="alert-success alert">
        <strong class="text-success">Your category create successfully!</strong>
      </Base-alert>
    </section>
    <section v-else-if="alert_act === 'deleted'">
      <Base-alert v-if="alert_me" class="alert-danger alert">
        <strong class="text-danger">Your category delete successfully!</strong>
      </Base-alert>
    </section>

    <section class="search p-4">
      <form class="d-flex w-50 m-auto" @submit.prevent>
        <input
          class="form-control me-2"
          type="search"
          placeholder="Search"
          aria-label="Search"
        />
        <Base-btn class="btn search--btn text-white">Search</Base-btn>
        <Base-btn
          class="btn btn-outline-primary float-end ms-5"
          data-bs-toggle="modal"
          data-bs-target="#create_modal"
          >Create</Base-btn
        >
      </form>
    </section>
    <section>
      <!-- Modal create  -->
      <Base-modal-create :modal_title="modal_title">
        <template #modal-body>
          <form class="mb-5" autocomplete="off">
            <div class="mb-3">
              <label for="recipient-name" class="col-form-label"
                >Please input your category name:</label
              >
              <input
                type="text"
                class="form-control"
                placeholder="Categories name..."
                id="recipient-name"
                v-model="name"
              />
            </div>
          </form>
        </template>
        <template #modal-footer>
          <Base-btn class="btn btn-danger" data-bs-dismiss="modal"
            >Cancel</Base-btn
          >
          <Base-btn
            class="btn btn-primary"
            @click="create()"
            data-bs-dismiss="modal"
            >+Add</Base-btn
          >
        </template>
      </Base-modal-create>
      <!-- Modal edit  -->
<Base-modal-edit :modal_title="modal_title">
<template #modal-body>
          <form class="mb-5" autocomplete="off">
            <div class="mb-3">
              <label for="recipient-name" class="col-form-label"
                >Please input your category name:</label
              >
              <input
                type="text"
                class="form-control"
                placeholder="Categories name..."
                id="recipient-name"
                v-model="name"
              />
            </div>
          </form>
        </template>
        <template #modal-footer>
          <Base-btn class="btn btn-danger" data-bs-dismiss="modal"
            >Cancel</Base-btn
          >
          <Base-btn
            class="btn btn-success"
           @click="edit_cate"
            data-bs-dismiss="modal"
            >Update</Base-btn
          >
        </template>

</Base-modal-edit>
    </section>
    <section class="cate--card row row-cols-2 row-cols-md-2 g-3">
      <categories-card
        v-for="category of categories"
        :key="category.id"
        :category="category"
        @delete_cate="delete_cate"
        @get_id="get_id"
      ></categories-card>
    </section>
  </div>
</template>

<script>
import CategoriesCard from "@/components/pages/card/categories_card.vue";
import axios from "axios";

export default {
  components: {
    "categories-card": CategoriesCard,
  },
  data() {
    return {
      name: "",
      categories: [],
      id: 0,
      counter: 0,
      alert_me: false,
      alert_act: "",
    };
  },
  computed: {
    modal_title() {
      return "Categories";
    },
  },
  methods: {
    create() {
      let cate_name = {
        name: this.name,
      };
      if (this.name !== "") {
        axios
          .post("http://127.0.0.1:8000/api/categories", cate_name)
          .then((res) => {
            console.log(res.data.message);
              this.alert_act = "create";
              this.categories = res.data.categories;
            setInterval(() => {
              if (this.counter <2) {
                this.counter++;
                this.alert_me = true;
              } else {
                this.alert_me = false;
              }
            }, 900);
            this.counter = 0;
          })
          .catch((err) => {
            console.log(err.response.data.message);
          });
        this.name = "";
      }
    },
    delete_cate(id) {
      axios.delete("http://127.0.0.1:8000/api/categories/" + id).then((res) => {
        this.alert_act = "deleted";
        this.categories = res.data.categories;
        setInterval(() => {
          if (this.counter < 3) {
            this.counter++;
            this.alert_me = true;
          } else {
            this.alert_me = false;
          }
        }, 900);
        this.counter = 0;
      });
    },
    get_id(id) {
      this.id = id
    },
    edit_cate(){
      console.log(this.id);
      axios.get("http://127.0.0.1:8000/api/categories").then((res) => {
      this.categories = res.data;
    });
    }
  },
  mounted() {
    axios.get("http://127.0.0.1:8000/api/categories").then((res) => {
      this.categories = res.data;
    });
  },
};
</script>

<style scoped>
.search {
  background: var(--sidebar-bg-color);
}
.search .search--btn {
  background: var(--sidebar-item-active);
}
</style>