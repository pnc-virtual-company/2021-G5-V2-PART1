<template>
  <section>
    <div class="col">
      <div class="card m-3">
        <div class="card-body">
          <h5 class="card-title">{{ category.name }}</h5>
          <Base-btn
            class="btn btn-sm btn-danger float-end"
            @click="$emit('delete_cate', category.id)"
            >Delete</Base-btn
          >

          <Base-btn
            class="btn btn-sm btn-primary float-end me-2"
            data-bs-toggle="modal"
            data-bs-target="#edit_modal"
           @click="$emit('get_id', category.id)"
            >Edit</Base-btn
          >
        </div>
      </div>
    </div>
  </section>
</template>
<script>
export default {
  props: ["category"],
  methods: {},
};
</script>